//
//  CanadaTableViewApp.swift
//  CanadaTableView
//
//  Created by M_AMBIN05148 on 05/04/22.
//

import SwiftUI

@main
struct CanadaTableViewApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
